#!/bin/bash

./saml.py Admin 530730979689
