import os
import sys

# Add the project base directory to the sys.path
# sys.path.append('/var/task')

from django.core.wsgi import get_wsgi_application
from mangum import Mangum

# Set the environment variable for Django settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'streaming.settings')

# Create the Django application
application = get_wsgi_application()

# Create the Mangum handler for the ASGI application
lambda_handler = Mangum(application)
