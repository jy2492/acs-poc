#!/bin/bash

# PATH=$PATH:$LAMBDA_TASK_ROOT/bin \
#     PYTHONPATH=$PYTHONPATH:/opt/python:$LAMBDA_RUNTIME_DIR \
#     exec python -m uvicorn --port=$PORT streaming.asgi:application
PATH=$PATH:$LAMBDA_TASK_ROOT/bin \
    PYTHONPATH=$PYTHONPATH:/opt/python:$LAMBDA_RUNTIME_DIR \
    exec python -m gunicorn streaming.wsgi:application -w=1 -b=0.0.0.0:$PORT
