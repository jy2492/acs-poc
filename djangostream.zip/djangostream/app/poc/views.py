from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST
import json
import logging
import time


LOG = logging.getLogger(__name__)


@require_GET
def main_view(request):
    return render(request, 'main.html')


@csrf_exempt
@require_POST
def get_stream_data(request):

    # data = json.loads(request.body.decode('utf-8'))
    text_data = "Creating AWS accounts for the Columbia community under the University’s enterprise agreement and consolidated billing. Also known as AWS, AWS sub-account and AWS consolidated billing.  Columbia University negotiated an enterprise agreement with Amazon Web Services (AWS) in December 2015. If you are a faculty member or administrator who uses AWS for Columbia purposes, your AWS account is required to go through the University Enterprise Agreement. Student and personal AWS accounts are not covered under the enterprise agreement. This agreement provides a number of benefits to faculty and staff, most notably the ability to pay for AWS services in a manner that is in compliance with University procurement policy. It also also provides intellectual property protection, liability and other protections. As of April 2017, Columbia University has signed a Business Associate Agreement (BAA) with Amazon Web Service (AWS), permitting Columbia users that are appropriately enrolled to host Personal Health Information (PHI) in AWS, while maintaining HIPAA compliance."
    chunk_size = 40
    fetched_data = [text_data[i:i + chunk_size] for i in range(0, len(text_data), chunk_size)]

    # async def stream_data(data):
    def stream_data(data):
        for dt in data:
            yield dt
            # yield {'message': dt}
            time.sleep(0.5)

    # content_type = 'text/plain; charset=utf-8'
    # content_type = 'application/json charset=utf-8'
    content_type = 'text/event-stream; charset=utf-8'
    response = StreamingHttpResponse(stream_data(fetched_data), content_type=content_type)
    response['X-Accel-Buffering'] = 'no'  # Disable buffering in nginx
    response['Cache-Control'] = 'no-cache'  # Ensure clients don't cache the data
    return response
